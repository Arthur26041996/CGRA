/**
 * MyUnitCube
 * @param gl {WebGLRenderingContext}
 * @constructor
 */

class MyUnitCube extends CGFobject
{
	constructor(scene)
	{
		super(scene);
		this.initBuffers();
	};

	initBuffers()
	{
		this.vertices = [
                // X    Y    Z
				-0.5, -0.5, 0.5,   // A 0
                0.5, -0.5, 0.5,    // B 1
                -0.5, 0.5, 0.5,    // C 2
                0.5, 0.5, 0.5,     // D 3
                -0.5, -0.5, -0.5,  // E 4
                0.5, -0.5, -0.5,   // F 5
                -0.5, 0.5, -0.5,   // G 6
                0.5, 0.5, -0.5     // H 7
				];

		this.indices = [
				0, 1, 2,        // ABC
                3, 2, 1,        // DCB
                0, 6, 4,        // AGE
                0, 2, 6,        // ACG
                1, 5, 7,        // BFH
                1, 7, 3,        // BHD
                5, 4, 6,        // FEG
                5, 6, 7,        // FGH
                0, 4, 1,        // AEB
                1, 4, 5,        // BEF
                2, 3, 6,        // CDG
                3, 7, 6         // DHG
			];

		this.primitiveType=this.scene.gl.TRIANGLES;
		this.initGLBuffers();
	};
};
